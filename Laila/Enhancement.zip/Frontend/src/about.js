gsap.fromTo(".title-text", { opacity: 0, y: -100}, {opacity: 1, y: 0, duration: 1});
gsap.fromTo(".media", { opacity: 0, y: 100}, {opacity: 1, y: 0, duration: 1});
gsap.fromTo(".count-data", { opacity: 0, x: 200}, {opacity: 1, x: 0, duration: 1.5});