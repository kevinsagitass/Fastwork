<footer class="text-center" style="max-height: 100px; background-color: cadetblue">
    <h6 class="m-0 p-1">@Happy Book Store 2022</h6>
</footer>
<?php /**PATH F:\Fastwork\Fastwork\Jack\laravel\giant-book\resources\views/layout/partials/footer.blade.php ENDPATH**/ ?>