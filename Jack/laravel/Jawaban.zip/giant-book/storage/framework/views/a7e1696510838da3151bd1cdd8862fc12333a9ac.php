
<?php $__env->startSection('content'); ?>
    <div>
        <?php $__currentLoopData = $publishers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $publisher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row" style="background-color: grey">
                <div class="col-6">
                    <h4 class="text-white">Name : <?php echo e($publisher->name); ?></h4>
                    <h4 class="text-white">Address : <?php echo e($publisher->address); ?></h4>
                    <h4 class="text-white">Phone : <?php echo e($publisher->phone); ?></h4>
                    <h4 class="text-white">Email : <?php echo e($publisher->email); ?></h4>
                </div>
                <div class="col-6">
                    <img class="w-50 float-right" style="max-height: 300px" src="<?php echo e(asset('/storage/profiles/'.$publisher->image)); ?>">
                </div>
            </div>
            <div class="row">
                <?php $__currentLoopData = $publisher->books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-4 col-md-3">
                        <div class="card w-100 m-3">
                            <img class="card-img-top" src="<?php echo e(asset('storage/books/' . $book->image)); ?>"
                                style="height: 100%; max-height: 300px" />
                            <div class="card-body">
                                <h3 class="card-title"><?php echo e($book->title); ?></h3>
                                <h4>By</h4>
                                <h4 class="card-text"><?php echo e($book->author); ?></h4>
                            </div>
                            <div class="card-footer">
                                <a href="<?php echo e('/book/' . $book->id); ?>" class="btn btn-primary">Book Detail</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Fastwork\Fastwork\Jack\laravel\giant-book\resources\views/publisher.blade.php ENDPATH**/ ?>