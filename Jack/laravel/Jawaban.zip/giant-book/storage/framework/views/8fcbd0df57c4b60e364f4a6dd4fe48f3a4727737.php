
<?php $__env->startSection('content'); ?>
    <div>
        <div class="row">
            <div class="col-12" style="background-color: grey">
                <h3 class="text-white">Book List</h3>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-4 col-md-3">
                    <div class="card w-100 m-3">
                        <img class="card-img-top" src="<?php echo e(asset('storage/books/' . $book->image)); ?>"
                            style="height: 100%; max-height: 300px" />
                        <div class="card-body">
                            <h3 class="card-title"><?php echo e($book->title); ?></h3>
                            <h4>By</h4>
                            <h4 class="card-text"><?php echo e($book->author); ?></h4>
                        </div>
                        <div class="card-footer">
                            <a href="<?php echo e('/book/' . $book->id); ?>" class="btn btn-primary">Book Detail</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Fastwork\Fastwork\Jack\laravel\giant-book\resources\views/home.blade.php ENDPATH**/ ?>