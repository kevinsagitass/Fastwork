
<?php $__env->startSection('content'); ?>
    <div>
        <div class="row">
            <div class="col-12" style="background-color: grey">
                <h3 class="text-white">Book Detail</h3>
            </div>
        </div>
        <div class="row">
            <div class="col-12 text-center">
                <img class="card-img-top w-50 mt-3" src="<?php echo e(asset('storage/books/' . $book->image)); ?>" />
                <div class="mt-3">
                    <h1>Title : <?php echo e($book->title); ?></h1>
                    <h1>Author : <?php echo e($book->author); ?></h1>
                    <h1>Publisher : <?php echo e($book->publisher->name); ?></h1>
                    <h1>Year : <?php echo e($book->year); ?></h1>
                    <h2>Synopsis : </h2>
                    <div>
                        <p><?php echo e($book->synopsis); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Fastwork\Fastwork\Jack\laravel\giant-book\resources\views/book_detail.blade.php ENDPATH**/ ?>