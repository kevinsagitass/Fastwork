@extends('layout.mainlayout')
@section('content')
    <div>
        <div class="row mb-3">
            <div class="col-12" style="background-color: grey">
                <h3 class="text-white">Contact</h3>
            </div>
        </div>
        <div class="p-3">
            <h2>Store Address : </h2>
            <h3>Jalan Pembangunan Baru Raya,</h3>
            <h3>Kompleks Pertokoan Emerald Blok III/12</h3>
            <h3>Bintaro, Tangerang Selatan</h3>
            <h3>Indonesia</h3> <br>
            <h2>Open Daily : </h2>
            <h3>08:00 - 20:00</h3> <br>
            <h2>Contact : </h2>
            <h3>Phone : 021-08899776655</h3>
            <h3>Email : happybookstore@happy.com</h3>
        </div>
    </div>
@endsection
