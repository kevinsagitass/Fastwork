package entity;

public class Gold extends Theme{
	
	public Gold() {
		this.background = "#FFD700";
		this.border = "solid, emas gelap";
		this.icon = "gambar koin emas";
		this.music = "musik klasik";
	}
}
