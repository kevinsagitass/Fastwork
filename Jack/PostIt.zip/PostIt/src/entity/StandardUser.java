package entity;

public class StandardUser extends User {
	
	public StandardUser() {
		this.maxCharacter = 500;
	}
}
