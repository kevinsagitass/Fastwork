package entity;

public class VIP extends Theme{
	
	public VIP() {
		this.background = "#E5E4E2";
		this.border = "solid, warna putih bersih";
		this.icon = "gambar mahkota";
		this.music = "musik klasik";
	}
}
