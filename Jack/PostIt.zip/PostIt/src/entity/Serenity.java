package entity;

public class Serenity extends Theme {
	
	public Serenity() {
		this.background = "#EFEFEF";
		this.border = "solid, warna putih salju dengan bayangan hitam";
		this.icon = "Rubah Putih";
		this.music = "Musik yang Tenang";
	}
}
