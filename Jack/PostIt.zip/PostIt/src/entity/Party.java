package entity;

public class Party extends Theme{
	
	public Party() {
		this.background = "#F9A7B0";
		this.border = "putus-putus, warna merah maroon";
		this.icon = "gambar orang berdansa";
		this.music = "musik yang semangat dan menarik";
	}
}
