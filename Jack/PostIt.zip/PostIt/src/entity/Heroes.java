package entity;

public class Heroes extends Theme{
	
	public Heroes() {
		this.background = "#376282";
		this.border = "solid, warna abu-abu gelap metalik";
		this.icon = "gambar superhero";
		this.music = "musik orkestra yang tegang dan bersemangat";
	}
}
